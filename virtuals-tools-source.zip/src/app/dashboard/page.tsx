"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getAccess, clearAccess, type AccessInfo } from "@/lib/auth";

export default function DashboardPage() {
  const [access, setAccess] = useState<AccessInfo | null>(null);

  useEffect(() => {
    setAccess(getAccess());
  }, []);

  if (access === null) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center text-zinc-500">Loading…</main>
        <Footer />
      </div>
    );
  }

  if (!access.active) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 max-w-md mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold mb-3">No active access</h1>
          <p className="text-zinc-400 mb-8 text-sm">
            Pay via Mobile Money to 0555801855 and activate a code to use the tools.
          </p>
          <div className="flex flex-col gap-3">
            <Link href="/pricing" className="bg-emerald-500 hover:bg-emerald-400 text-black font-semibold py-3 rounded-xl transition">
              View Pricing
            </Link>
            <Link href="/activate" className="border border-zinc-700 hover:border-zinc-500 text-zinc-200 py-3 rounded-xl transition">
              Activate Code
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const expiresText = access.expiresAt
    ? new Date(access.expiresAt).toLocaleString()
    : "Unknown";

  const daysLeft = access.expiresAt
    ? Math.max(0, Math.ceil((access.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 max-w-2xl mx-auto px-4 py-12 w-full">
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-zinc-400 mb-10 text-sm">Your current access status</p>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-zinc-400">Status</span>
            <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded-full font-medium">
              Active
            </span>
          </div>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-zinc-400">Package</span>
              <span className="font-medium capitalize">{access.packageId || "—"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-400">Expires</span>
              <span className="font-medium">{expiresText}</span>
            </div>
            {daysLeft !== null && (
              <div className="flex justify-between">
                <span className="text-zinc-400">Days remaining</span>
                <span className="font-medium text-emerald-400">{daysLeft}</span>
              </div>
            )}
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mb-8">
          <Link
            href="/upload"
            className="bg-emerald-500 hover:bg-emerald-400 text-black font-semibold py-4 rounded-xl text-center transition"
          >
            Upload Screenshot
          </Link>
          <Link
            href="/pricing"
            className="border border-zinc-700 hover:border-zinc-500 text-zinc-200 font-medium py-4 rounded-xl text-center transition"
          >
            Extend / New Package
          </Link>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 text-sm text-zinc-400">
          <p className="mb-2 font-medium text-zinc-300">Quick reminder</p>
          <p>
            This tool only extracts matches and odds from your screenshot using OCR.
            It does not predict results. Virtual football is random.
          </p>
        </div>

        <button
          onClick={() => {
            clearAccess();
            window.location.href = "/";
          }}
          className="mt-8 text-sm text-zinc-500 hover:text-red-400 transition"
        >
          Clear access on this device
        </button>
      </main>

      <Footer />
    </div>
  );
}
