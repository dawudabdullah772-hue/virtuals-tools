"use client";

import { useState } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const PACKAGES = [
  {
    id: "day",
    name: "1-Day Access",
    price: "GHS 20",
    description: "Unlimited screenshot uploads for 24 hours",
    codeHint: "VTDAY20",
  },
  {
    id: "week",
    name: "7-Day Access",
    price: "GHS 50",
    description: "Unlimited uploads for one week",
    popular: true,
    codeHint: "VTWEEK50",
  },
  {
    id: "month",
    name: "30-Day Access",
    price: "GHS 120",
    description: "Full month of unlimited use",
    codeHint: "VTMONTH120",
  },
];

const MOMO_NUMBER = "0555801855";

export default function PricingPage() {
  const [selected, setSelected] = useState("week");
  const [copied, setCopied] = useState(false);
  const [txId, setTxId] = useState("");

  const selectedPkg = PACKAGES.find((p) => p.id === selected)!;

  const copyNumber = async () => {
    try {
      await navigator.clipboard.writeText(MOMO_NUMBER);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      alert("Copy this number: " + MOMO_NUMBER);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 max-w-3xl mx-auto px-4 py-12 w-full">
        <h1 className="text-3xl font-bold text-center mb-2">Pricing</h1>
        <p className="text-zinc-400 text-center mb-10">
          Pay once via Mobile Money. After payment you receive an activation
          code to unlock the tool.
        </p>

        <div className="grid gap-4 mb-10">
          {PACKAGES.map((pkg) => (
            <button
              key={pkg.id}
              onClick={() => setSelected(pkg.id)}
              className={`text-left p-5 rounded-2xl border transition ${
                selected === pkg.id
                  ? "border-emerald-500 bg-emerald-500/10"
                  : "border-zinc-800 bg-zinc-900 hover:border-zinc-700"
              }`}
            >
              <div className="flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold">{pkg.name}</span>
                    {pkg.popular && (
                      <span className="text-xs bg-emerald-500 text-black px-2 py-0.5 rounded-full font-medium">
                        Popular
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-zinc-400 mt-1">{pkg.description}</p>
                </div>
                <span className="text-xl font-bold text-emerald-400 whitespace-nowrap">
                  {pkg.price}
                </span>
              </div>
            </button>
          ))}
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 mb-6">
          <h2 className="font-semibold text-lg mb-5">Pay with Mobile Money</h2>

          <ol className="space-y-5 text-sm text-zinc-300 mb-6">
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">1</span>
              <span>Open your Mobile Money app (MTN, Telecel, or AirtelTigo) or dial the USSD code for your network.</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">2</span>
              <div>
                <p className="mb-3">
                  Send <strong className="text-white text-base">{selectedPkg.price}</strong> to this number:
                </p>
                <div className="flex items-center gap-3 bg-zinc-950 border border-zinc-700 rounded-xl p-4">
                  <div className="flex-1">
                    <p className="text-xs text-zinc-500 mb-1">Mobile Money Number</p>
                    <p className="text-2xl font-mono font-bold tracking-wider text-emerald-400">{MOMO_NUMBER}</p>
                  </div>
                  <button onClick={copyNumber} className="bg-zinc-800 hover:bg-zinc-700 text-sm px-4 py-2 rounded-lg transition shrink-0">
                    {copied ? "Copied!" : "Copy"}
                  </button>
                </div>
              </div>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">3</span>
              <span>
                Reference / name on the transfer:{" "}
                <strong className="text-white">Virtuals Tools – {selectedPkg.name}</strong>
              </span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">4</span>
              <span>
                After the money is sent, keep the transaction ID. Contact the operator of this number and you will receive an activation code
                (example format: <code className="text-emerald-400 text-xs">{selectedPkg.codeHint}</code>).
              </span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold">5</span>
              <span>
                Go to the <Link href="/activate" className="text-emerald-400 underline">Activate</Link> page, enter the code, and you immediately get access.
              </span>
            </li>
          </ol>

          <div className="bg-zinc-950 rounded-xl p-4 text-sm">
            <p className="text-zinc-400 mb-2">Optional — save your transaction ID here for your own records</p>
            <input
              type="text"
              value={txId}
              onChange={(e) => setTxId(e.target.value)}
              placeholder="e.g. 123456789012"
              className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-4 py-2.5 text-white placeholder:text-zinc-600 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 text-sm text-zinc-300 mb-6">
          <strong className="text-amber-400">Note:</strong> Payments are manual Mobile Money transfers to <strong>0555801855</strong>.
          Access is unlocked only after you receive and enter a valid activation code.
        </div>

        <div className="text-center">
          <Link href="/activate" className="inline-block bg-emerald-500 hover:bg-emerald-400 text-black font-semibold px-8 py-3 rounded-xl transition">
            I already have a code → Activate
          </Link>
        </div>
      </main>

      <Footer />
    </div>
  );
}
