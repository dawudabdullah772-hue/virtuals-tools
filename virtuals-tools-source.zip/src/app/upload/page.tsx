"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getAccess, type AccessInfo } from "@/lib/auth";
import {
  extractTextFromImage,
  parseMatchesFromText,
  type ExtractedMatch,
} from "@/lib/ocr";

export default function UploadPage() {
  const [access, setAccess] = useState<AccessInfo | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [status, setStatus] = useState<"idle" | "processing" | "done" | "error">("idle");
  const [progress, setProgress] = useState(0);
  const [matches, setMatches] = useState<ExtractedMatch[]>([]);
  const [rawText, setRawText] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setAccess(getAccess());
  }, []);

  const handleFile = (selected: File | null) => {
    if (!selected) return;
    if (!selected.type.startsWith("image/")) {
      alert("Please select an image file (PNG, JPG, WEBP, etc.)");
      return;
    }
    if (selected.size > 12 * 1024 * 1024) {
      alert("Image is too large. Please use a file under 12 MB.");
      return;
    }
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
    setStatus("idle");
    setMatches([]);
    setRawText("");
    setErrorMsg("");
    setProgress(0);
  };

  const processImage = async () => {
    if (!file) return;
    setStatus("processing");
    setProgress(0);
    setErrorMsg("");

    try {
      const text = await extractTextFromImage(file, setProgress);
      const parsed = parseMatchesFromText(text);
      setRawText(text);
      setMatches(parsed);
      setStatus("done");
    } catch (err: any) {
      console.error(err);
      setErrorMsg(
        err?.message ||
          "OCR failed. Check your internet connection (Tesseract loads from CDN) and try again."
      );
      setStatus("error");
    }
  };

  if (access === null) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center text-zinc-500">Loading…</main>
        <Footer />
      </div>
    );
  }

  if (!access.active) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 max-w-md mx-auto px-4 py-20 text-center">
          <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-6 text-2xl">
            🔒
          </div>
          <h1 className="text-2xl font-bold mb-3">Access required</h1>
          <p className="text-zinc-400 mb-8 text-sm leading-relaxed">
            The upload & OCR tool is available after you pay via Mobile Money
            to <span className="font-mono text-emerald-400">0555801855</span>{" "}
            and activate your code.
          </p>
          <div className="flex flex-col gap-3">
            <Link href="/pricing" className="bg-emerald-500 hover:bg-emerald-400 text-black font-semibold py-3 rounded-xl transition">
              View Pricing & Pay
            </Link>
            <Link href="/activate" className="border border-zinc-700 hover:border-zinc-500 text-zinc-200 py-3 rounded-xl transition">
              I already have a code
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 max-w-3xl mx-auto px-4 py-12 w-full">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-3xl font-bold">Upload Screenshot</h1>
          <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded-full">
            Access active
          </span>
        </div>
        <p className="text-zinc-400 mb-8 text-sm">
          Upload a SportyBet Instant Virtual screenshot. OCR extracts the
          visible matches and odds.{" "}
          <strong className="text-zinc-200">No outcome predictions.</strong>
        </p>

        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            handleFile(e.dataTransfer.files[0] || null);
          }}
          className="border-2 border-dashed border-zinc-700 hover:border-emerald-500/50 rounded-2xl p-8 sm:p-10 text-center cursor-pointer transition mb-6 bg-zinc-900/50"
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFile(e.target.files?.[0] || null)}
          />
          {preview ? (
            <div className="space-y-4">
              <img src={preview} alt="Preview" className="max-h-72 mx-auto rounded-lg border border-zinc-700" />
              <p className="text-sm text-zinc-400">{file?.name}</p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFile(null);
                  setPreview(null);
                  setStatus("idle");
                  setMatches([]);
                  setRawText("");
                }}
                className="text-sm text-red-400 hover:text-red-300"
              >
                Remove image
              </button>
            </div>
          ) : (
            <div>
              <p className="text-zinc-300 mb-2">Drag & drop or click to select image</p>
              <p className="text-xs text-zinc-500">PNG, JPG, WEBP · ideally under 5–8 MB for faster OCR</p>
            </div>
          )}
        </div>

        {file && status !== "processing" && (
          <button
            onClick={processImage}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-semibold py-3.5 rounded-xl transition mb-8"
          >
            Extract Matches & Odds with OCR
          </button>
        )}

        {status === "processing" && (
          <div className="text-center py-10 space-y-4">
            <div className="text-zinc-300">Running OCR… {progress}%</div>
            <div className="w-full max-w-xs mx-auto h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 transition-all duration-300" style={{ width: `${progress}%` }} />
            </div>
            <p className="text-xs text-zinc-500">First run may take longer while the OCR engine loads from CDN.</p>
          </div>
        )}

        {status === "error" && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 text-sm text-red-300 mb-6">
            {errorMsg}
          </div>
        )}

        {status === "done" && (
          <div className="space-y-6">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
              <h2 className="font-semibold mb-4 flex items-center justify-between">
                <span>Extracted matches</span>
                <span className="text-xs text-zinc-500 font-normal">{matches.length} found</span>
              </h2>

              {matches.length === 0 ? (
                <p className="text-sm text-zinc-400">
                  No clear “Team vs Team” lines were detected. Check the raw text below — OCR quality depends on screenshot clarity.
                </p>
              ) : (
                <ul className="space-y-3">
                  {matches.map((m, i) => (
                    <li key={i} className="bg-zinc-950 rounded-xl px-4 py-3 text-sm">
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <span className="font-medium">
                          {m.home} <span className="text-zinc-500 font-normal">vs</span> {m.away}
                        </span>
                        {(m.oddsHome || m.oddsDraw || m.oddsAway) && (
                          <span className="font-mono text-zinc-400 text-xs">
                            {[m.oddsHome, m.oddsDraw, m.oddsAway].filter(Boolean).join("  ·  ")}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-zinc-600 mt-1 truncate">{m.rawLine}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
              <h2 className="font-semibold mb-3">Raw OCR text</h2>
              <pre className="text-xs text-zinc-400 whitespace-pre-wrap font-mono bg-zinc-950 rounded-xl p-4 overflow-auto max-h-72">
                {rawText || "(empty)"}
              </pre>
            </div>

            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 text-sm text-zinc-300">
              <strong className="text-amber-400">Reminder:</strong> This is only an extraction of what appears on the image.
              It is <strong>not</strong> a prediction of who will win. Virtual football results are random.
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
