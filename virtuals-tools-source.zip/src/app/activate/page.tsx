"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { activateWithCode, getAccess } from "@/lib/auth";
import { useEffect } from "react";

export default function ActivatePage() {
  const [code, setCode] = useState("");
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [alreadyActive, setAlreadyActive] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const access = getAccess();
    setAlreadyActive(access.active);
  }, []);

  const handleActivate = (e: React.FormEvent) => {
    e.preventDefault();
    const result = activateWithCode(code);
    if (result.ok) {
      setMessage({ type: "ok", text: result.message });
      setTimeout(() => router.push("/upload"), 1500);
    } else {
      setMessage({ type: "err", text: result.message });
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 max-w-md mx-auto px-4 py-16 w-full">
        <h1 className="text-3xl font-bold text-center mb-2">Activate Access</h1>
        <p className="text-zinc-400 text-center mb-10 text-sm">
          Enter the activation code you received after paying via Mobile Money
          to <span className="font-mono text-emerald-400">0555801855</span>.
        </p>

        {alreadyActive && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 text-sm text-emerald-300 mb-6 text-center">
            You already have active access.{" "}
            <a href="/upload" className="underline">
              Go to Upload
            </a>
          </div>
        )}

        <form onSubmit={handleActivate} className="space-y-4">
          <div>
            <label className="block text-sm text-zinc-400 mb-2">
              Activation code
            </label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="e.g. VTWEEK50"
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 text-white font-mono tracking-wider placeholder:text-zinc-600 focus:outline-none focus:border-emerald-500 uppercase"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-semibold py-3.5 rounded-xl transition"
          >
            Activate
          </button>
        </form>

        {message && (
          <div
            className={`mt-6 rounded-xl p-4 text-sm ${
              message.type === "ok"
                ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-300"
                : "bg-red-500/10 border border-red-500/30 text-red-300"
            }`}
          >
            {message.text}
          </div>
        )}

        <div className="mt-10 bg-zinc-900 border border-zinc-800 rounded-xl p-5 text-sm text-zinc-400">
          <p className="mb-3 font-medium text-zinc-300">How to get a code</p>
          <ol className="list-decimal list-inside space-y-2">
            <li>Pay the package amount to 0555801855 via Mobile Money</li>
            <li>Contact the number owner with your transaction ID</li>
            <li>You will be given a code such as VTDAY20 / VTWEEK50 / VTMONTH120</li>
            <li>Enter it here to unlock the tool</li>
          </ol>
          <p className="mt-4 text-xs text-zinc-500">
            Demo / testing code: <code className="text-emerald-400">DEMOACCESS</code>
          </p>
        </div>
      </main>

      <Footer />
    </div>
  );
}
