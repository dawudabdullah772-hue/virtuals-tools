// Client-side access control for the honest demo version.
// In production replace with Supabase / NextAuth + real database + server-generated codes.

const ACCESS_KEY = "virtuals_tools_access";
const ACCESS_EXPIRY_KEY = "virtuals_tools_expiry";

export type AccessInfo = {
  active: boolean;
  packageId?: string;
  expiresAt?: number;
};

export function getAccess(): AccessInfo {
  if (typeof window === "undefined") return { active: false };

  const token = localStorage.getItem(ACCESS_KEY);
  const expiry = localStorage.getItem(ACCESS_EXPIRY_KEY);

  if (!token) return { active: false };

  if (expiry) {
    const exp = parseInt(expiry, 10);
    if (Date.now() > exp) {
      clearAccess();
      return { active: false };
    }
    return {
      active: true,
      packageId: token,
      expiresAt: exp,
    };
  }

  return { active: true, packageId: token };
}

export function grantAccess(packageId: string, days: number) {
  if (typeof window === "undefined") return;
  const expiresAt = Date.now() + days * 24 * 60 * 60 * 1000;
  localStorage.setItem(ACCESS_KEY, packageId);
  localStorage.setItem(ACCESS_EXPIRY_KEY, String(expiresAt));
}

export function clearAccess() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(ACCESS_KEY);
  localStorage.removeItem(ACCESS_EXPIRY_KEY);
}

/**
 * Activation codes you give to users AFTER confirming their Mobile Money payment to 0555801855.
 * In production generate unique one-time codes on the server.
 */
const VALID_CODES: Record<string, { packageId: string; days: number }> = {
  VTDAY20: { packageId: "day", days: 1 },
  VTWEEK50: { packageId: "week", days: 7 },
  VTMONTH120: { packageId: "month", days: 30 },
  // Testing only
  DEMOACCESS: { packageId: "week", days: 7 },
};

export function activateWithCode(code: string): { ok: boolean; message: string } {
  const normalized = code.trim().toUpperCase();
  const entry = VALID_CODES[normalized];
  if (!entry) {
    return {
      ok: false,
      message: "Invalid activation code. Contact support after your Mobile Money payment.",
    };
  }
  grantAccess(entry.packageId, entry.days);
  return {
    ok: true,
    message: `Access granted for ${entry.days} day(s). Redirecting to upload…`,
  };
}
