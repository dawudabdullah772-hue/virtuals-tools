// Client-side OCR helpers.
// Uses Tesseract.js loaded from CDN so the project works even if npm install is incomplete.

export type ExtractedMatch = {
  home: string;
  away: string;
  oddsHome?: string;
  oddsDraw?: string;
  oddsAway?: string;
  rawLine: string;
};

declare global {
  interface Window {
    Tesseract?: any;
  }
}

let tesseractPromise: Promise<any> | null = null;

function loadTesseract(): Promise<any> {
  if (typeof window === "undefined") {
    return Promise.reject(new Error("OCR only runs in the browser"));
  }
  if (window.Tesseract) return Promise.resolve(window.Tesseract);

  if (tesseractPromise) return tesseractPromise;

  tesseractPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";
    script.async = true;
    script.onload = () => {
      if (window.Tesseract) resolve(window.Tesseract);
      else reject(new Error("Tesseract failed to load"));
    };
    script.onerror = () => reject(new Error("Failed to load Tesseract from CDN"));
    document.head.appendChild(script);
  });

  return tesseractPromise;
}

export async function extractTextFromImage(
  file: File,
  onProgress?: (p: number) => void
): Promise<string> {
  const Tesseract = await loadTesseract();

  const result = await Tesseract.recognize(file, "eng", {
    logger: (m: any) => {
      if (m.status === "recognizing text" && typeof m.progress === "number") {
        onProgress?.(Math.round(m.progress * 100));
      }
    },
  });

  return result.data.text || "";
}

/**
 * Very simple heuristic parser for SportyBet-style Instant Virtual text.
 * Looks for lines that contain "vs" / "v" / "-" between team-like words
 * and nearby numbers that look like odds.
 */
export function parseMatchesFromText(text: string): ExtractedMatch[] {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const matches: ExtractedMatch[] = [];
  const vsRegex = /(.+?)\s+(?:vs\.?|v\.?|-)\s+(.+)/i;
  const oddsRegex = /(\d+[.,]\d{2})/g;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const m = line.match(vsRegex);
    if (!m) continue;

    let home = m[1].replace(/[^a-zA-Z0-9\s]/g, "").trim();
    let away = m[2].replace(/[^a-zA-Z0-9\s]/g, "").trim();

    // Clean common OCR noise
    home = home.replace(/\s+/g, " ").slice(0, 30);
    away = away.replace(/\s+/g, " ").slice(0, 30);

    if (home.length < 2 || away.length < 2) continue;

    // Look for odds on the same line or the next 1-2 lines
    const searchText = [line, lines[i + 1] || "", lines[i + 2] || ""].join(" ");
    const oddsFound = [...searchText.matchAll(oddsRegex)].map((x) =>
      x[1].replace(",", ".")
    );

    matches.push({
      home,
      away,
      oddsHome: oddsFound[0],
      oddsDraw: oddsFound[1],
      oddsAway: oddsFound[2],
      rawLine: line,
    });
  }

  // Deduplicate roughly
  const seen = new Set<string>();
  return matches.filter((m) => {
    const key = `${m.home}|${m.away}`.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
