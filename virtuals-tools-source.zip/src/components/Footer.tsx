export default function Footer() {
  return (
    <footer className="border-t border-zinc-800 py-8 mt-auto">
      <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-zinc-500">
        <p>© 2026 Virtuals Tools — Honest analysis only. No outcome predictions.</p>
        <p>
          Mobile Money:{" "}
          <span className="text-emerald-400 font-mono font-medium">
            0555801855
          </span>
        </p>
      </div>
    </footer>
  );
}
