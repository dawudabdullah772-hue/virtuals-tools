"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { getAccess, clearAccess, type AccessInfo } from "@/lib/auth";

export default function Header() {
  const [access, setAccess] = useState<AccessInfo>({ active: false });
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    setAccess(getAccess());
  }, []);

  const handleLogout = () => {
    clearAccess();
    setAccess({ active: false });
    window.location.href = "/";
  };

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur sticky top-0 z-50">
      <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center font-bold text-black text-sm">
            VT
          </div>
          <span className="font-semibold text-lg tracking-tight">Virtuals Tools</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden sm:flex items-center gap-5 text-sm">
          <Link href="/upload" className="text-zinc-400 hover:text-white transition">Upload</Link>
          <Link href="/dashboard" className="text-zinc-400 hover:text-white transition">Dashboard</Link>
          <Link href="/pricing" className="text-zinc-400 hover:text-white transition">Pricing</Link>
          <Link href="/activate" className="text-zinc-400 hover:text-white transition">Activate</Link>

          {access.active ? (
            <div className="flex items-center gap-2">
              <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded-full">Active</span>
              <button onClick={handleLogout} className="text-zinc-500 hover:text-zinc-300 text-xs">Clear</button>
            </div>
          ) : (
            <Link href="/pricing" className="bg-emerald-500 hover:bg-emerald-400 text-black font-medium px-3 py-1.5 rounded-lg transition text-sm">
              Get Access
            </Link>
          )}
        </nav>

        {/* Mobile menu button */}
        <button
          className="sm:hidden text-zinc-400 p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Menu"
        >
          {menuOpen ? "✕" : "☰"}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="sm:hidden border-t border-zinc-800 bg-zinc-950 px-4 py-4 space-y-3 text-sm">
          <Link href="/upload" className="block text-zinc-300" onClick={() => setMenuOpen(false)}>Upload</Link>
          <Link href="/dashboard" className="block text-zinc-300" onClick={() => setMenuOpen(false)}>Dashboard</Link>
          <Link href="/pricing" className="block text-zinc-300" onClick={() => setMenuOpen(false)}>Pricing</Link>
          <Link href="/activate" className="block text-zinc-300" onClick={() => setMenuOpen(false)}>Activate</Link>
          {access.active ? (
            <button onClick={handleLogout} className="block text-red-400">Clear access</button>
          ) : (
            <Link href="/pricing" className="block text-emerald-400 font-medium" onClick={() => setMenuOpen(false)}>Get Access</Link>
          )}
        </div>
      )}
    </header>
  );
}
