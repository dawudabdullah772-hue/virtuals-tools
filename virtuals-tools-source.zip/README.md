# Virtuals Tools — Honest Technical Version

Complete Next.js web app for SportyBet Instant Virtual / Instant Football screenshot analysis.

**No fake AI predictions. No 97% win-rate claims. Virtual football is pure RNG.**

---

## Features

- Landing page with clear disclaimers
- Pricing + **Mobile Money 0555801855**
- Activation codes after payment
- Access-gated upload + real OCR (Tesseract)
- Match & odds parser
- Dashboard (status, expiry, days left)
- Responsive mobile UI + “Add to Home Screen” support
- Dark theme, mobile menu, safe-area support for notched phones

---

## Run on computer

```bash
cd instant-virtuals-honest
npm install
npm run dev
```

Open http://localhost:3000

---

## Run / test on your phone (same Wi-Fi)

1. On the computer:
   ```bash
   npm run dev -- -H 0.0.0.0
   ```

2. Find your computer’s IP:
   - Windows → `ipconfig` → IPv4 Address
   - Mac → System Settings → Network → Wi-Fi

3. On the phone browser open:
   ```
   http://YOUR-IP:3000
   ```
   Example: `http://192.168.1.45:3000`

4. Optional – make it feel like an app:
   - Chrome → menu → **Add to Home screen**
   - Safari (iPhone) → Share → **Add to Home Screen**

---

## Mobile Money (0555801855)

| Code          | Access   |
|---------------|----------|
| `VTDAY20`     | 1 day    |
| `VTWEEK50`    | 7 days   |
| `VTMONTH120`  | 30 days  |
| `DEMOACCESS`  | 7 days (testing) |

User pays → you confirm → give code → user activates on `/activate`.

---

## Deploy for real users (public mobile link)

**Easiest:** Vercel

1. Push the project to GitHub (or use Vercel CLI)
2. Import the repo on vercel.com
3. Deploy → you get a link like `https://your-app.vercel.app`
4. Open that link on any phone

Or use your existing hosting if it supports Node.js / Next.js.

---

## Project structure

```
src/
  app/
    page.tsx              Home
    pricing/page.tsx      Pricing + MoMo
    activate/page.tsx     Enter code
    upload/page.tsx       OCR (gated)
    dashboard/page.tsx    Status
    not-found.tsx
    layout.tsx            Mobile + PWA meta
    globals.css
  components/
    Header.tsx            Mobile menu
    Footer.tsx
  lib/
    auth.ts
    ocr.ts
public/
  manifest.json           Add to Home Screen
  icon.svg
```

---

## Honest positioning

This tool only extracts what is visible on the screenshot.  
It never claims to know the result of an RNG virtual match.
